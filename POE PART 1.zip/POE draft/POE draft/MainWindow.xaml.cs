﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace POE_draft
{
    
        public partial class MainWindow : Window
        {
            public MainWindow()
            {
                InitializeComponent();
                LoadSampleData();
            }

            private void LoadSampleData()
            {
                // Sample claims data
                var claims = new List<Claim>
            {
                new Claim
                {
                    ClaimId = "CLM-0089",
                    DateSubmitted = "15 Aug 2025",
                    Period = "July 2025",
                    Hours = "42",
                    Amount = "R12,600",
                    Status = "Pending Review",
                    StatusBackground = new SolidColorBrush(Color.FromRgb(255, 243, 205)),
                    StatusForeground = new SolidColorBrush(Color.FromRgb(133, 100, 4))
                },
                new Claim
                {
                    ClaimId = "CLM-0085",
                    DateSubmitted = "02 Aug 2025",
                    Period = "July 2025",
                    Hours = "38",
                    Amount = "R11,400",
                    Status = "Approved",
                    StatusBackground = new SolidColorBrush(Color.FromRgb(212, 237, 218)),
                    StatusForeground = new SolidColorBrush(Color.FromRgb(21, 87, 36))
                },
                new Claim
                {
                    ClaimId = "CLM-0081",
                    DateSubmitted = "18 Jul 2025",
                    Period = "June 2025",
                    Hours = "40",
                    Amount = "R12,000",
                    Status = "Paid",
                    StatusBackground = new SolidColorBrush(Color.FromRgb(212, 237, 218)),
                    StatusForeground = new SolidColorBrush(Color.FromRgb(21, 87, 36))
                },
                new Claim
                {
                    ClaimId = "CLM-0076",
                    DateSubmitted = "03 Jul 2025",
                    Period = "June 2025",
                    Hours = "32",
                    Amount = "R9,600",
                    Status = "Paid",
                    StatusBackground = new SolidColorBrush(Color.FromRgb(212, 237, 218)),
                    StatusForeground = new SolidColorBrush(Color.FromRgb(21, 87, 36))
                }
            };

                ClaimsDataGrid.ItemsSource = claims;

                // Sample approvals data
                var approvals = new List<Approval>
            {
                new Approval
                {
                    ClaimId = "CLM-0090",
                    Lecturer = "Dr. James Wilson",
                    DateSubmitted = "16 Aug 2025",
                    Amount = "R13,200",
                    CurrentStage = "Program Coordinator Review"
                },
                new Approval
                {
                    ClaimId = "CLM-0089",
                    Lecturer = "Dr. Sarah Johnson",
                    DateSubmitted = "15 Aug 2025",
                    Amount = "R12,600",
                    CurrentStage = "Program Coordinator Review"
                },
                new Approval
                {
                    ClaimId = "CLM-0087",
                    Lecturer = "Prof. Richard Brown",
                    DateSubmitted = "12 Aug 2025",
                    Amount = "R14,800",
                    CurrentStage = "Academic Manager Review"
                }
            };

                ApprovalsDataGrid.ItemsSource = approvals;
            }

            private void NavButton_Click(object sender, RoutedEventArgs e)
            {
                if (sender is Button button)
                {
                    string viewName = button.Tag.ToString();
                    ContentTitle.Text = viewName;

                    // In a real application, you would switch views here
                    MessageBox.Show($"Switching to {viewName} view", "Navigation", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }

            private void LogoutButton_Click(object sender, RoutedEventArgs e)
            {
                MessageBox.Show("Logging out...", "Logout", MessageBoxButton.OK, MessageBoxImage.Information);
                // In a real application, you would close the session and show the login screen
            }

            private void ViewClaimButton_Click(object sender, RoutedEventArgs e)
            {
                if (sender is Button button && button.DataContext is Claim claim)
                {
                    MessageBox.Show($"Viewing claim {claim.ClaimId}", "View Claim", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }

            private void SubmitClaimButton_Click(object sender, RoutedEventArgs e)
            {
                MessageBox.Show("Opening claim submission form", "Submit Claim", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            private void ApproveClaimButton_Click(object sender, RoutedEventArgs e)
            {
                if (sender is Button button && button.DataContext is Approval approval)
                {
                    MessageBox.Show($"Approving claim {approval.ClaimId}", "Approve Claim", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }

            private void RejectClaimButton_Click(object sender, RoutedEventArgs e)
            {
                if (sender is Button button && button.DataContext is Approval approval)
                {
                    MessageBox.Show($"Rejecting claim {approval.ClaimId}", "Reject Claim", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }

        public class Claim
        {
            public string ClaimId { get; set; }
            public string DateSubmitted { get; set; }
            public string Period { get; set; }
            public string Hours { get; set; }
            public string Amount { get; set; }
            public string Status { get; set; }
            public Brush StatusBackground { get; set; }
            public Brush StatusForeground { get; set; }
        }

        public class Approval
        {
            public string ClaimId { get; set; }
            public string Lecturer { get; set; }
            public string DateSubmitted { get; set; }
            public string Amount { get; set; }
            public string CurrentStage { get; set; }
        }
    }